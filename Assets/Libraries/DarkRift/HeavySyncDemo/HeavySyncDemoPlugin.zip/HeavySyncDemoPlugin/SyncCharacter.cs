﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using DarkRift;

namespace HeavySyncDemo
{
    /// <summary>
    ///     Represents a character spawned.
    /// </summary>
    class SyncCharacter
    {
        /// <summary>
        ///     The current position of the character.
        /// </summary>
        public volatile float x, y, z;

        /// <summary>
        ///     The ID of this chracter.
        /// </summary>
        public volatile ushort ID;

        /// <summary>
        /// The ID of the owner of this character.
        /// </summary>
        public volatile ushort owner;

        /// <summary>
        ///     The last time a client updated the position of this character.
        /// </summary>
        DateTime lastUpdate;

        /// <summary>
        ///     Lock update for lastUpdate.
        /// </summary>
        Object lastUpdateLock = new Object();

        /// <summary>
        ///     Creates a new SyncCharacter.
        /// </summary>
        /// <param name="x">The x position.</param>
        /// <param name="y">The y position.</param>
        /// <param name="z">The z position.</param>
        /// <param name="ID">The ID of this character.</param>
        /// <param name="owner">The owner of this character.</param>
        public SyncCharacter(float x, float y, float z, ushort ID, ushort owner)
        {
            this.x = x;
            this.y = y;
            this.z = z;
            this.ID = ID;
            this.owner = owner;

            lastUpdate = DateTime.Now;
        }

        /// <summary>
        ///     Validates whether the new position is allowable.
        /// </summary>
        /// <param name="newX">The next x position.</param>
        /// <param name="newY">The next y position.</param>
        /// <param name="newZ">The next z position.</param>
        /// <returns>Whether the new position is valid.</returns>
        public bool ValidatePositionUpdate(float newX, float newY, float newZ)
        {
            double deltaTime;

            //Get the change in time.
            lock (lastUpdateLock)
                deltaTime = (DateTime.Now - lastUpdate).TotalSeconds;

            //Get the component speeds
            double xSpeed = (newX - x) / deltaTime;
            double ySpeed = (newY - y) / deltaTime;
            double zSpeed = (newZ - z) / deltaTime;

            //Check speeds are less than 4
            return xSpeed < 4 && ySpeed < 4 && zSpeed < 4;
        }

        /// <summary>
        ///     Updates the position of the character.
        /// </summary>
        /// <param name="newX">The new x position.</param>
        /// <param name="newY">The new y position.</param>
        /// <param name="newZ">The new z position.</param>
        public void UpdatePosition(float newX, float newY, float newZ)
        {
            x = newX;
            y = newY;
            z = newZ;

            //Update the last update time
            lock (lastUpdateLock)
                lastUpdate = DateTime.Now;
        }
    }
}
