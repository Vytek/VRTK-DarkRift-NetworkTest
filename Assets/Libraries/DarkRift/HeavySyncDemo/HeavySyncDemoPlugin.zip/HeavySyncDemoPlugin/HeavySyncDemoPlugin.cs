﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using DarkRift;
using System.Timers;
using System.Threading;

namespace HeavySyncDemo
{
    /// <summary>
    ///     Demo plugin for the Heavy Sync Demo.
    /// </summary>
    public class HeavySyncDemoPlugin : Plugin
    {
        /// <summary>
        ///     The tags we will use in communication.
        /// </summary>
        public const byte SPAWN_TAG = 0;
        public const byte DESPAWN_TAG = 1;
        public const byte SYNC_TAG = 2;

        /// <summary>
        ///     The name of the plugin.
        /// </summary>
        public override string name
        {
            get { return "HeavySyncDemoPlugin"; }
        }

        /// <summary>
        ///     The version of the plugin.
        /// </summary>
        public override string version
        {
            get { return "1.0"; }
        }

        /// <summary>
        ///     The author of the plugin.
        /// </summary>
        public override string author
        {
            get { return "Jamie Read"; }
        }

        /// <summary>
        ///     The email for support with the plugin.
        /// </summary>
        public override string supportEmail
        {
            get { return "Jamie.read@outlook.com"; }
        }

        /// <summary>
        ///     The commands this plugin has.
        /// </summary>
        public override Command[] commands
        {
            //No commands, return an empty array
            get { return new Command[0]; }
        }

        /// <summary>
        ///     The list of characters we currently have spawned.
        /// </summary>
        Dictionary<ushort, SyncCharacter> characters = new Dictionary<ushort, SyncCharacter>();

        /// <summary>
        ///     The next id that will be allocated to a character by the plugin
        /// </summary>
        int nextIDToAllocate = -1;

        /// <summary>
        ///     Constructor, called when the plugin is loaded.
        /// </summary>
        public HeavySyncDemoPlugin()
        {
            //Subscribe to the events we need
            ConnectionService.onPostPlayerConnect += OnPostPlayerConnect;
            ConnectionService.onPlayerDisconnect += OnPlayerDisconnect;
            ConnectionService.onData += OnData;
        }

        /// <summary>
        ///     Called when the player has connected and has been added to the list of players.
        /// </summary>
        /// <param name="con">The connection to the player.</param>
        void OnPostPlayerConnect(ConnectionService con)
        {
            //First we need to spawn the characters that are curently spawned on our new client
            Interface.Log("Spawning the current " + characters.Count + " characters on new client.");
            
            //Create a writer to send initial spawn data from
            using (DarkRiftWriter writer = new DarkRiftWriter())
            {
                //Lock on characters so it doesn't change
                lock (characters)
                {
                    //Write the number of characters we need spawned
                    writer.Write((ushort)characters.Count);

                    //Write the details of each character to the writer
                    foreach (SyncCharacter character in characters.Values)
                    {
                        writer.Write(character.x);
                        writer.Write(character.y);
                        writer.Write(character.z);
                        writer.Write(character.ID);
                        writer.Write(character.owner);
                    }
                }

                //Send the writer to the newly connected player.
                con.SendReply(SPAWN_TAG, 0, writer);
            }

            //Finally lets create another 100 characters on all the clients
            Interface.Log("Spawning another 100 characters on all client.");
            SpawnSyncCharacters(100, con.id);
        }

        /// <summary>
        ///     Called when a player disconnects.
        /// </summary>
        /// <param name="con"></param>
        void OnPlayerDisconnect(ConnectionService con)
        {
            //We need to ensure that everyone despawns that client's characters as there's
            //noone to control them any more!
            using (DarkRiftWriter writer = new DarkRiftWriter())
            {
                //Lock on characters so it doesn't change
                lock (characters)
                {
                    //Create a list of the clients that need to be removed
                    List<SyncCharacter> toRemove = new List<SyncCharacter>();

                    //Populate it and remove from the dictionary of characters
                    KeyValuePair<ushort, SyncCharacter>[] chars = characters.ToArray();
                    for (int i = 0; i < chars.Length; i++)
                    {
                        if (chars[i].Value.owner == con.id)
                        {
                            characters.Remove(chars[i].Key);
                            toRemove.Add(chars[i].Value);
                        }
                    }

                    //Write the number of characters that need to be removed to the writer
                    writer.Write((ushort)toRemove.Count);

                    //And write the ID of each character to the writer
                    foreach (SyncCharacter character in toRemove)
                        writer.Write(character.ID);

                    Interface.Log("Removing player's characters");

                    //Finally send it to all the remaining clients
                    foreach (ConnectionService connection in DarkRiftServer.GetAllConnections())
                        connection.SendReply(DESPAWN_TAG, 0, writer);
                }
            }
        }

        /// <summary>
        ///     Called when a message passes through the server.
        /// </summary>
        /// <param name="con">The conenction servvice that is was received from.</param>
        /// <param name="data">The message that was received</param>
        void OnData(ConnectionService con, ref NetworkMessage data)
        {
            //If the data is sync data...
            if (data.tag == SYNC_TAG)
            {
                //Decode the data so we can open it
                data.DecodeData();

                using (DarkRiftReader reader = data.data as DarkRiftReader)
                using (DarkRiftWriter writer = new DarkRiftWriter())
                {
                    //Get the number of characters the packet is about
                    ushort count = reader.ReadUInt16();

                    //Repack length
                    writer.Write(count);

                    //For each character...
                    for (int i = 0; i < count; i++)
                    {
                        bool got;
                        SyncCharacter character;

                        //Lock characters and check the character actually exists
                        lock (characters)
                            got = characters.TryGetValue(reader.ReadUInt16(), out character);

                        if (got)
                        {
                            //Check they own the character
                            if (data.senderID == character.owner)
                            {
                                //Get position
                                float x = reader.ReadSingle();
                                float y = reader.ReadSingle();
                                float z = reader.ReadSingle();

                                //Validate and update 
                                if (character.ValidatePositionUpdate(x, y, z))
                                {
                                    character.UpdatePosition(x, y, z);
                                }

                                //Repack data with actual position
                                writer.Write(character.ID);
                                writer.Write(character.x);
                                writer.Write(character.y);
                                writer.Write(character.z);

                            }
                            else
                                Interface.LogWarning("A client attempted to access a character they dont own.");
                        }
                        else
                            Interface.LogWarning("A client attempted to access a non existant character.");
                    }

                    //Reassign the data variable of the message
                    data.data = writer;
                }
            }
        }

        /// <summary>
        ///     Spawns a number of new characters for the given client.
        /// </summary>
        /// <param name="number">The number of chracters to spawn.</param>
        /// <param name="owner">The client to set as the owner.</param>
        void SpawnSyncCharacters(ushort number, ushort owner)
        {
            using (DarkRiftWriter writer = new DarkRiftWriter())
            {
                //Write the number to the writer
                writer.Write(number);

                Random r = new Random();

                //Foreach character...
                for (int i = 0; i < number; i++)
                {
                    SyncCharacter character;
                    ushort id;
                    
                    //Get a new, unique ID
                    id = (ushort)Interlocked.Increment(ref nextIDToAllocate);

                    //Create the server-side SyncCharacter object with random position
                    character = new SyncCharacter(
                        (float)(r.NextDouble() * 100),
                        0,
                        (float)(r.NextDouble() * 100),
                        id,
                        owner
                    );

                    //Write the new character to the writer
                    //No need to lock character, we're the only thread with a reference
                    writer.Write(character.x);
                    writer.Write(character.y);
                    writer.Write(character.z);
                    writer.Write(character.ID);
                    writer.Write(character.owner);

                    //Add the new character to the list of characters
                    lock (characters)
                        characters.Add(character.ID, character);
                }

                //Update all clients with the new characters
                foreach (ConnectionService connection in DarkRiftServer.GetAllConnections())
                    connection.SendReply(SPAWN_TAG, 0, writer);
            }
        }
    }
}
